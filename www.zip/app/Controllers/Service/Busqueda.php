<?php

namespace App\Controllers\Service;

use CodeIgniter\RESTful\ResourceController;


class Busqueda extends ResourceController
{
    protected $modelName = 'App\Models\BusquedaModel'; // Asegúrate de tener este modelo
    protected $format    = 'json';

    public $builder;

    public function __construct() {
           $db      = \Config\Database::connect();
        $this->builder = $db->table('infoIncautaciones'); 
    }
    // Método para buscar la información de la incautación por placa
    public function buscar_por_placa($placa = null)
    {
        if (!$placa) {
            return $this->respond(['msg'=>'Placa no proporcionada', 'status'=>'error']);
        }

        //$data = $this->model->where('placa', $placa)->first();
        $data = $this->model->searchByPlaca($placa);

        if (!$data) {
            return $this->respond(['msg'=>'No se encontró la incautación con esa placa', 'status'=>'error']);
        }

        return $this->respond($data);
    }

    public function update_rq_ubi(){
        
        // return $this->respond($this->request->getPost());
        //$pass = $this->request->getPost('password');
        $placa = $this->request->getPost('placa');
        $rq = $this->request->getPost('rq');
        $ubicado = $this->request->getPost('ubicado');
        $idusuario = $this->request->getPost('idusuario');

        $data = ['rq'=>$rq,'ubicado'=>$ubicado, 'idusuario'=>$idusuario];

        // $modelBusq = model('BusquedaModel');

        //$update = $this->model->update($data,'placa="AMX636"');

        $this->builder->where('placa',$placa);

        $this->builder->update($data);

        // if (!$update) {
        //     return $this->respond(['msg'=>'Los campos rq y/o ubicado no se actualizaron', 'status'=>'error']);
        // } 
        
        return $this->respond(['msg'=>'Actualización exitosa', 'status'=>'ok']);

        // return $this->respond($data);
        
    }
}
