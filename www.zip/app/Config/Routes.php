<?php

use CodeIgniter\Router\RouteCollection;

/**
 * @var RouteCollection $routes
 */

$routes->presenter('service/usuarios');

$routes->post('login', 'Service\Usuarios::signin');
$routes->get('busqueda/por-placa/(:segment)', 'Service\Busqueda::buscar_por_placa/$1');
$routes->post('busqueda/actualizar', 'Service\Busqueda::update_rq_ubi');

